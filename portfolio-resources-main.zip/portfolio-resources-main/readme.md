# Developer Portfolio Website Resources
## Steps
1. open cmd
2. cd `\projects`
3. git clone https://github.com/ProgrammingHero1/portfolio-resources.git
4. visit [www.figma.com/](https://www.figma.com/)
5. create account
6. drag and drop the `developer-portfolio.fig`
7. Enjoy !!! 
